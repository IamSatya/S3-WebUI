from fastapi import FastAPI, Query, HTTPException, Header
from fastapi.middleware.cors import CORSMiddleware
import boto3
from botocore.config import Config
import os
from pydantic import BaseModel
import sqlalchemy
from sqlalchemy import create_engine
from sqlalchemy.sql import select
from models import metadata, users
from auth import hash_password, verify_password, create_access_token, decode_token
from datetime import datetime, timezone
import json

# --- S3 client setup ---
app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

AWS_REGION = os.getenv("AWS_REGION", "ap-south-1")
S3_BUCKET = os.getenv("S3_BUCKET", "")
if not S3_BUCKET:
    print("Warning: S3_BUCKET not set. Some operations may fail.")

s3_client = boto3.client(
    "s3",
    region_name=AWS_REGION,
    config=Config(signature_version="s3v4")
)

# --- Database (SQLite using SQLAlchemy Core) ---
DB_URL = os.getenv("DATABASE_URL", "sqlite:///./users.db")
engine = create_engine(DB_URL, connect_args={"check_same_thread": False} if DB_URL.startswith("sqlite") else {})
metadata.create_all(engine)

# create initial admin user if provided via env
ADMIN_EMAIL = os.getenv("ADMIN_USER_EMAIL")
ADMIN_PASSWORD = os.getenv("ADMIN_USER_PASSWORD")
if ADMIN_EMAIL and ADMIN_PASSWORD:
    with engine.connect() as conn:
        q = select(users).where(users.c.email == ADMIN_EMAIL)
        r = conn.execute(q).fetchone()
        if not r:
            conn.execute(users.insert().values(email=ADMIN_EMAIL, password_hash=hash_password(ADMIN_PASSWORD), role="admin"))
            print(f"Created admin user: {ADMIN_EMAIL}")

# --- Auth helper functions ---
def get_current_user(authorization: str | None = Header(None)):
    if not authorization:
        raise HTTPException(status_code=401, detail="Missing Authorization header")
    if not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Invalid Authorization header")
    token = authorization.split(" ", 1)[1]
    payload = decode_token(token)
    if not payload:
        raise HTTPException(status_code=401, detail="Invalid token")
    sub = payload.get("sub")
    if not sub:
        raise HTTPException(status_code=401, detail="Invalid token payload")
    # load user from DB
    with engine.connect() as conn:
        q = select(users).where(users.c.email == sub)
        row = conn.execute(q).fetchone()
        if not row:
            raise HTTPException(status_code=401, detail="User not found")
        return {"email": row["email"], "role": row["role"]}

# --- Models for requests ---
class FileRequest(BaseModel):
    filename: str
    filetype: str | None = None

class RegisterIn(BaseModel):
    email: str
    password: str

class LoginIn(BaseModel):
    email: str
    password: str

# --- Cutoff config ---
HACKATHON_CUTOFF_ISO = os.getenv("HACKATHON_CUTOFF_ISO")  # e.g. 2025-10-25T18:00:00+05:30

def cutoff_reached() -> bool:
    if not HACKATHON_CUTOFF_ISO:
        return False
    try:
        cutoff_dt = datetime.fromisoformat(HACKATHON_CUTOFF_ISO)
        # normalize to aware in UTC
        if cutoff_dt.tzinfo is None:
            cutoff_dt = cutoff_dt.replace(tzinfo=timezone.utc)
        now = datetime.now(timezone.utc)
        return now > cutoff_dt.astimezone(timezone.utc)
    except Exception as e:
        print("Error parsing HACKATHON_CUTOFF_ISO:", e)
        return False

# --- Auth endpoints ---
@app.post("/api/register")
def register(payload: RegisterIn):
    with engine.connect() as conn:
        q = select(users).where(users.c.email == payload.email)
        if conn.execute(q).fetchone():
            raise HTTPException(status_code=400, detail="Email already registered")
        ph = hash_password(payload.password)
        conn.execute(users.insert().values(email=payload.email, password_hash=ph, role="user"))
    return {"status": "ok"}

@app.post("/api/login")
def login(payload: LoginIn):
    with engine.connect() as conn:
        q = select(users).where(users.c.email == payload.email)
        row = conn.execute(q).fetchone()
        if not row or not verify_password(payload.password, row["password_hash"]):
            raise HTTPException(status_code=401, detail="Invalid credentials")
        token = create_access_token(subject=row["email"], role=row["role"])
        return {"access_token": token, "token_type": "bearer", "role": row["role"]}

@app.get("/api/me")
def me(user=Depends(get_current_user)):
    return {"email": user["email"], "role": user["role"]}

# --- Existing endpoints (modified) ---

@app.post("/api/generate_presigned_url")
def generate_presigned_url(request: FileRequest, authorization: str | None = Header(None)):
    # auth
    user = get_current_user(authorization)
    # cutoff enforcement
    if cutoff_reached() and user["role"] != "admin":
        raise HTTPException(status_code=403, detail="Upload cutoff reached")

    # enforce prefix for non-admins
    if user["role"] != "admin":
        safe_prefix = f\"users/{user['email']}/\"
        if not request.filename.startswith(safe_prefix):
            raise HTTPException(status_code=403, detail=f\"Key must start with user prefix: {safe_prefix}\")

    presigned_url = s3_client.generate_presigned_url(
        "put_object",
        Params={"Bucket": S3_BUCKET, "Key": request.filename},
        ExpiresIn=3600,
    )
    return {"url": presigned_url}

from fastapi import Depends

@app.get("/api/get_presigned_download_url")
def get_presigned_download_url(key: str = Query(...), authorization: str | None = Header(None)):
    # auth check: allow admin or owner
    user = get_current_user(authorization)
    if user["role"] != "admin":
        prefix = f\"users/{user['email']}/\"
        if not key.startswith(prefix):
            raise HTTPException(status_code=403, detail=\"Not allowed to access this object\")
    presigned_url = s3_client.generate_presigned_url(
        "get_object",
        Params={"Bucket": S3_BUCKET, "Key": key},
        ExpiresIn=3600,
    )
    return {"url": presigned_url}

@app.get("/api/list_files")
def list_files(prefix: str = "", authorization: str | None = Header(None)):
    # auth check: if user is not admin, prefix is forced to their prefix
    user = get_current_user(authorization)
    if user["role"] != "admin":
        prefix = f\"users/{user['email']}/\"

    response = s3_client.list_objects_v2(Bucket=S3_BUCKET, Prefix=prefix, Delimiter="/")
    files = []
    for folder in response.get("CommonPrefixes", []):
        files.append({
            "key": folder["Prefix"],
            "name": folder["Prefix"].split("/")[-2],
            "isFolder": True
        })
    for obj in response.get("Contents", []):
        # skip the folder marker objects (they end with /)
        if obj["Key"].endswith("/"):
            continue
        files.append({
            "key": obj["Key"],
            "name": obj["Key"].split("/")[-1],
            "size": obj["Size"],
            "last_modified": obj["LastModified"].isoformat()
        })
    return {"files": files}

@app.delete("/api/delete_file")
def delete_file(key: str = Query(...), authorization: str | None = Header(None)):
    user = get_current_user(authorization)
    # only admin or owner can delete
    if user["role"] != "admin":
        prefix = f\"users/{user['email']}/\"
        if not key.startswith(prefix):
            raise HTTPException(status_code=403, detail=\"Not allowed to delete this object\")
    s3_client.delete_object(Bucket=S3_BUCKET, Key=key)
    return {"message": f\"{key} deleted successfully\"}

@app.post("/api/create_folder")
def create_folder(prefix: str = Query(...), authorization: str | None = Header(None)):
    user = get_current_user(authorization)
    if user["role"] != "admin":
        # ensure folder is under user's prefix
        if not prefix.startswith(f\"users/{user['email']}/\"):
            raise HTTPException(status_code=403, detail=\"Folder must be under your user prefix\")
    if not prefix.endswith("/"):
        prefix += "/"
    s3_client.put_object(Bucket=S3_BUCKET, Key=prefix)
    return {"message": f\"Folder '{prefix}' created successfully\"}