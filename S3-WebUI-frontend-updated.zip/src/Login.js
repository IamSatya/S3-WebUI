import React, { useState, useContext } from "react";
import axios from "axios";
import { AuthContext } from "./AuthContext";

export default function Login() {
  const { saveToken } = useContext(AuthContext);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState(null);

  async function submit(e) {
    e.preventDefault();
    try {
      const res = await axios.post((process.env.REACT_APP_BACKEND_URL || "") + "/api/login", {
        email,
        password,
      });
      saveToken(res.data.access_token);
      setError(null);
    } catch (err) {
      console.error(err);
      setError(err?.response?.data?.detail || "Login failed");
    }
  }

  return (
    <div style={{ marginBottom: 12 }}>
      <h3>Login</h3>
      <form onSubmit={submit}>
        <input placeholder='email' value={email} onChange={(e)=>setEmail(e.target.value)} />
        <input placeholder='password' type='password' value={password} onChange={(e)=>setPassword(e.target.value)} />
        <button type='submit'>Login</button>
      </form>
      {error && <div style={{color:'red'}}>{error}</div>}
    </div>
  );
}