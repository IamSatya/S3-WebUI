import React, { useState } from "react";
import axios from "axios";

export default function Register() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [msg, setMsg] = useState(null);

  async function submit(e) {
    e.preventDefault();
    try {
      await axios.post((process.env.REACT_APP_BACKEND_URL || "") + "/api/register", { email, password });
      setMsg("Registered successfully — please login.");
    } catch (err) {
      console.error(err);
      setMsg(err?.response?.data?.detail || "Registration failed");
    }
  }

  return (
    <div style={{ marginBottom: 12 }}>
      <h3>Register</h3>
      <form onSubmit={submit}>
        <input placeholder='email' value={email} onChange={(e)=>setEmail(e.target.value)} />
        <input placeholder='password' type='password' value={password} onChange={(e)=>setPassword(e.target.value)} />
        <button type='submit'>Register</button>
      </form>
      {msg && <div>{msg}</div>}
    </div>
  );
}