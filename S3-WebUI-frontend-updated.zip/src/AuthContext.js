import React, { createContext, useState, useEffect } from "react";
import axios from "axios";

export const AuthContext = createContext(null);

export default function AuthProvider({ children }) {
  const [token, setToken] = useState(localStorage.getItem("access_token") || null);
  const [user, setUser] = useState(null);

  useEffect(() => {
    async function fetchMe() {
      if (!token) {
        setUser(null);
        return;
      }
      try {
        const res = await axios.get((process.env.REACT_APP_BACKEND_URL || "") + "/api/me", {
          headers: { Authorization: "Bearer " + token },
        });
        setUser(res.data);
      } catch (err) {
        console.error("Failed to fetch /me", err);
        setUser(null);
        setToken(null);
        localStorage.removeItem("access_token");
      }
    }
    fetchMe();
  }, [token]);

  function saveToken(t) {
    if (t) {
      localStorage.setItem("access_token", t);
    } else {
      localStorage.removeItem("access_token");
    }
    setToken(t);
  }

  return <AuthContext.Provider value={{ token, saveToken, user, setUser }}>{children}</AuthContext.Provider>;
}