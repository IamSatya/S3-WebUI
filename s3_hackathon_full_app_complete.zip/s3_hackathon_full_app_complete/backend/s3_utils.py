import os
import boto3
from botocore.exceptions import ClientError

AWS_REGION = os.getenv('AWS_REGION')
AWS_BUCKET = os.getenv('AWS_BUCKET')

def s3_client():
    return boto3.client('s3', region_name=AWS_REGION)

def upload_fileobj(fileobj, key, acl='private'):
    s3 = s3_client()
    s3.upload_fileobj(fileobj, AWS_BUCKET, key)
    return True

def generate_presigned_url(key, expires_in=3600):
    s3 = s3_client()
    try:
        url = s3.generate_presigned_url('get_object', Params={'Bucket': AWS_BUCKET, 'Key': key}, ExpiresIn=expires_in)
        return url
    except ClientError:
        return None

def delete_object(key):
    s3 = s3_client()
    try:
        s3.delete_object(Bucket=AWS_BUCKET, Key=key)
        return True
    except ClientError:
        return False

def list_objects(prefix):
    s3 = s3_client()
    try:
        resp = s3.list_objects_v2(Bucket=AWS_BUCKET, Prefix=prefix)
        return resp.get('Contents', [])
    except ClientError:
        return []
