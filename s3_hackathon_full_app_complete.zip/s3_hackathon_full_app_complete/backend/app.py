import os, io
from fastapi import FastAPI, HTTPException, Depends, UploadFile, File, Form
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from models import Base, User
from auth import get_password_hash, verify_password, create_access_token, decode_token
from s3_utils import upload_fileobj, generate_presigned_url, delete_object, list_objects
from datetime import datetime, timezone
from pydantic import BaseModel

DATABASE_URL = os.getenv('DATABASE_URL', 'sqlite:///app/data/hackathon.db')
UPLOAD_DIR = os.getenv('UPLOAD_DIR', '/app/data/uploads')
HACKATHON_CUTOFF = os.getenv('HACKATHON_CUTOFF')
SECRET_KEY = os.getenv('SECRET_KEY', 'please_change_this_in_prod')

engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False} if DATABASE_URL.startswith("sqlite") else {})
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base.metadata.create_all(bind=engine)

app = FastAPI(title="S3 Hackathon Backend")

class RegisterIn(BaseModel):
    username: str
    password: str

def get_current_user(token: str = Form(None) ):
    # token may come from Authorization header or form field; try header first via dependency in routes
    if not token:
        raise HTTPException(status_code=401, detail="Missing token")
    payload = decode_token(token)
    if not payload:
        raise HTTPException(status_code=401, detail="Invalid token")
    return payload.get("sub")

def is_cutoff_passed():
    if not HACKATHON_CUTOFF:
        return False
    try:
        cutoff = datetime.fromisoformat(HACKATHON_CUTOFF)
    except Exception:
        return False
    return datetime.now(timezone.utc) > cutoff.astimezone(timezone.utc)

@app.post("/api/register")
def register(data: RegisterIn):
    db = SessionLocal()
    try:
        if db.query(User).filter(User.username == data.username).first():
            raise HTTPException(status_code=400, detail="User exists")
        hashed = get_password_hash(data.password)
        u = User(username=data.username, hashed_password=hashed)
        db.add(u); db.commit(); db.refresh(u)
        return {"ok": True, "username": u.username}
    finally:
        db.close()

@app.post("/api/token")
def login(form_data: OAuth2PasswordRequestForm = Depends()):
    db = SessionLocal()
    try:
        user = db.query(User).filter(User.username == form_data.username).first()
        if not user or not verify_password(form_data.password, user.hashed_password):
            raise HTTPException(status_code=401, detail="Invalid credentials")
        token = create_access_token({"sub": user.username})
        return {"access_token": token, "token_type": "bearer"}
    finally:
        db.close()

@app.post("/api/upload")
async def upload_file(token: str = Form(...), file: UploadFile = File(...)):
    username = None
    payload = decode_token(token)
    if not payload:
        raise HTTPException(status_code=401, detail="Invalid token")
    username = payload.get("sub")
    if is_cutoff_passed():
        raise HTTPException(status_code=403, detail="Upload cutoff passed")
    key = f"{username}/{file.filename}"
    await file.seek(0)
    upload_fileobj(file.file, key)
    return {"ok": True, "key": key}

@app.post("/api/upload_folder")
async def upload_folder(token: str = Form(...), files: list[UploadFile] = File(...)):
    payload = decode_token(token)
    if not payload:
        raise HTTPException(status_code=401, detail="Invalid token")
    username = payload.get("sub")
    if is_cutoff_passed():
        raise HTTPException(status_code=403, detail="Upload cutoff passed")
    uploaded = []
    for f in files:
        key = f"{username}/{f.filename}"
        await f.seek(0)
        upload_fileobj(f.file, key)
        uploaded.append(key)
    return {"ok": True, "uploaded": uploaded}

@app.get("/api/list_files")
def list_files(token: str):
    payload = decode_token(token)
    if not payload:
        raise HTTPException(status_code=401, detail="Invalid token")
    username = payload.get("sub")
    prefix = f"{username}/"
    objs = list_objects(prefix)
    files = []
    for o in objs:
        files.append({"key": o['Key'], "size": o['Size'], "last_modified": o['LastModified'].isoformat()})
    return {"files": files}

@app.get("/api/download_url")
def download_url(token: str, key: str):
    payload = decode_token(token)
    if not payload:
        raise HTTPException(status_code=401, detail="Invalid token")
    username = payload.get("sub")
    if not key.startswith(f"{username}/"):
        raise HTTPException(status_code=403, detail="Not allowed")
    url = generate_presigned_url(key)
    if not url:
        raise HTTPException(status_code=500, detail="Could not generate url")
    return {"url": url}

@app.post("/api/delete")
def delete_file(token: str = Form(...), key: str = Form(...)):
    payload = decode_token(token)
    if not payload:
        raise HTTPException(status_code=401, detail="Invalid token")
    username = payload.get("sub")
    if not key.startswith(f"{username}/"):
        raise HTTPException(status_code=403, detail="Not allowed")
    ok = delete_object(key)
    if not ok:
        raise HTTPException(status_code=500, detail="Delete failed")
    return {"ok": True}
