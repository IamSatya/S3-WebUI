S3 Hackathon Backend

- Copy .env.example to .env and set AWS credentials + bucket.
- Build with: docker build -t s3_hackathon_backend .
- Or run with docker-compose up --build
- Endpoints:
  POST /api/register {username,password}
  POST /api/token (form) username, password -> access_token
  POST /api/upload (form) token, file
  POST /api/upload_folder (form with multiple files) token, files[]
  GET  /api/list_files?token=<token>
  GET  /api/download_url?token=<token>&key=<key>
  POST /api/delete (form) token, key
