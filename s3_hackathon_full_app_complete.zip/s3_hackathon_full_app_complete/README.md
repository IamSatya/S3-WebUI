S3 Hackathon Full App (Complete)

This bundle contains:
- docker-compose.yml to run backend + frontend
- backend/ : FastAPI app (SQLite + S3 operations)
- frontend/: React source (build via Dockerfile)

Please copy backend/.env.example to backend/.env and set AWS credentials and AWS_BUCKET.
The docker-compose sets HACKATHON_CUTOFF to 2025-11-05T18:00:00+05:30 by default.

To run with Docker Compose:
  docker-compose up --build -d

Notes:
- Frontend assumes backend is available at the same origin (/api/*). When running via compose, frontend is served on :8080 and backend on :8000.
- For local development, you may run backend with `uvicorn app:app --reload` inside backend/ after installing dependencies.
