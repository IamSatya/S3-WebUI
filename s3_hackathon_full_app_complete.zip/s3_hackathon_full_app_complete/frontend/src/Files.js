import React, {useState, useEffect, useRef} from 'react';

export default function Files({token}){
  const [files, setFiles] = useState([]);
  const [status, setStatus] = useState('');
  const fileRef = useRef();
  const folderRef = useRef();

  async function fetchFiles(){
    setStatus('loading');
    try{
      const res = await fetch('/api/list_files?token='+encodeURIComponent(token));
      const data = await res.json();
      if(!res.ok) throw new Error(JSON.stringify(data));
      setFiles(data.files || []);
      setStatus('');
    }catch(err){ setStatus('error: '+err.message); }
  }

  useEffect(()=>{ fetchFiles(); }, []);

  async function uploadOne(e){
    e.preventDefault();
    const f = fileRef.current.files[0];
    if(!f) return alert('no file');
    const form = new FormData();
    form.append('token', token);
    form.append('file', f);
    setStatus('uploading');
    const res = await fetch('/api/upload', {method:'POST', body: form});
    const data = await res.json();
    if(res.ok){ setStatus('uploaded'); fetchFiles(); } else setStatus('error: '+JSON.stringify(data));
  }

  async function uploadFolder(e){
    e.preventDefault();
    const files = folderRef.current.files;
    if(!files.length) return alert('no files');
    const form = new FormData();
    form.append('token', token);
    for(let i=0;i<files.length;i++) form.append('files', files[i]);
    setStatus('uploading folder');
    const res = await fetch('/api/upload_folder', {method:'POST', body: form});
    const data = await res.json();
    if(res.ok){ setStatus('uploaded'); fetchFiles(); } else setStatus('error: '+JSON.stringify(data));
  }

  async function getUrl(key){
    const res = await fetch('/api/download_url?token='+encodeURIComponent(token)+'&key='+encodeURIComponent(key));
    const data = await res.json();
    if(!res.ok) return alert('err: '+JSON.stringify(data));
    window.open(data.url, '_blank');
  }

  async function del(key){
    if(!window.confirm('Delete '+key+'?')) return;
    const form = new FormData();
    form.append('token', token);
    form.append('key', key);
    const res = await fetch('/api/delete', {method:'POST', body: form});
    const data = await res.json();
    if(res.ok) fetchFiles(); else alert('delete error: '+JSON.stringify(data));
  }

  return (
    <div style={{marginTop:20}}>
      <h2>Files</h2>
      <div style={{marginBottom:12}}>
        <form onSubmit={uploadOne} style={{display:'inline-block', marginRight:12}}>
          <input type='file' ref={fileRef} />
          <button>Upload File</button>
        </form>
        <form onSubmit={uploadFolder} style={{display:'inline-block'}}>
          <input type='file' ref={folderRef} webkitdirectory='true' directory='true' multiple />
          <button>Upload Folder</button>
        </form>
      </div>
      <div>Status: {status}</div>
      <table style={{width:'100%', marginTop:12, borderCollapse:'collapse'}}>
        <thead><tr><th style={{textAlign:'left'}}>Key</th><th>Size</th><th>Last Modified</th><th>Actions</th></tr></thead>
        <tbody>
          {files.map(f=>(
            <tr key={f.key} style={{borderTop:'1px solid #eee'}}>
              <td>{f.key}</td>
              <td style={{textAlign:'right'}}>{f.size}</td>
              <td>{f.last_modified}</td>
              <td>
                <button onClick={()=>getUrl(f.key)}>Download</button>
                <button onClick={()=>del(f.key)} style={{marginLeft:8}}>Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
