import React, {useState} from 'react';

export default function Login({onLogin}){
  const [user,setUser]=useState('');
  const [pass,setPass]=useState('');
  const [err,setErr]=useState(null);

  const submit=async e=>{
    e.preventDefault();
    setErr(null);
    const form = new URLSearchParams();
    form.append('username', user);
    form.append('password', pass);
    try{
      const res = await fetch('/api/token', {method:'POST', body: form});
      if(!res.ok) throw new Error(await res.text());
      const data = await res.json();
      onLogin(data.access_token, user);
    }catch(err){
      setErr(err.message);
    }
  };

  return (
    <form onSubmit={submit} style={{border:'1px solid #ddd', padding:16, borderRadius:8, minWidth:280}}>
      <h3>Login</h3>
      <div><input placeholder='username' value={user} onChange={e=>setUser(e.target.value)} required/></div>
      <div style={{marginTop:8}}><input placeholder='password' value={pass} onChange={e=>setPass(e.target.value)} type='password' required/></div>
      <div style={{marginTop:8}}><button type='submit'>Login</button></div>
      {err && <div style={{color:'red', marginTop:8}}>Error: {err}</div>}
    </form>
  );
}
