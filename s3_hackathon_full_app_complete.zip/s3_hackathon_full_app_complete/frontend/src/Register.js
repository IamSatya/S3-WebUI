import React, {useState} from 'react';

export default function Register(){
  const [user,setUser]=useState('');
  const [pass,setPass]=useState('');
  const [msg,setMsg]=useState(null);

  const submit=async e=>{
    e.preventDefault();
    setMsg(null);
    try{
      const res = await fetch('/api/register', {
        method:'POST',
        headers:{'Content-Type':'application/json'},
        body: JSON.stringify({username:user,password:pass})
      });
      const data = await res.json();
      if(!res.ok) throw new Error(data.detail || JSON.stringify(data));
      setMsg('Registered. Please login.');
      setUser(''); setPass('');
    }catch(err){
      setMsg('Error: '+err.message);
    }
  };

  return (
    <form onSubmit={submit} style={{border:'1px solid #ddd', padding:16, borderRadius:8, minWidth:280}}>
      <h3>Register</h3>
      <div><input placeholder='username' value={user} onChange={e=>setUser(e.target.value)} required/></div>
      <div style={{marginTop:8}}><input placeholder='password' value={pass} onChange={e=>setPass(e.target.value)} type='password' required/></div>
      <div style={{marginTop:8}}><button type='submit'>Register</button></div>
      {msg && <div style={{marginTop:8}}>{msg}</div>}
    </form>
  );
}
