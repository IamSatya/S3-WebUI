import React, {useState, useEffect} from 'react';
import Login from './Login';
import Register from './Register';
import Files from './Files';

function App(){
  const [token, setToken] = useState(localStorage.getItem('token') || null);
  const [username, setUsername] = useState(localStorage.getItem('username') || null);

  useEffect(()=>{
    if(token) localStorage.setItem('token', token);
    else localStorage.removeItem('token');
    if(username) localStorage.setItem('username', username);
    else localStorage.removeItem('username');
  }, [token, username]);

  return (
    <div style={{fontFamily:'Arial,Helvetica,sans-serif', padding:20}}>
      <h1>S3 Hackathon App</h1>
      {!token ? (
        <div style={{display:'flex', gap:20}}>
          <Login onLogin={(t,u)=>{ setToken(t); setUsername(u); }} />
          <Register />
        </div>
      ) : (
        <div>
          <div style={{display:'flex', justifyContent:'space-between', alignItems:'center'}}>
            <div>Signed in as <strong>{username}</strong></div>
            <div>
              <button onClick={()=>{ setToken(null); setUsername(null); }}>Logout</button>
            </div>
          </div>
          <Files token={token} />
        </div>
      )}
      <hr/>
      <footer style={{marginTop:20, fontSize:12}}>Backend must be running at the same host (http://localhost:8000). See README.</footer>
    </div>
  );
}

export default App;
