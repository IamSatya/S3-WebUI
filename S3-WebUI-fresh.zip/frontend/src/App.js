import React, { useContext } from 'react';
import { AuthContext } from './AuthContext';
import Login from './Login';
import Register from './Register';
import UploadPanel from './UploadPanel';
import FileList from './FileList';
import Instructions from './Instructions';
import CountdownTimer from './CountdownTimer';

export default function App(){
  const { user } = useContext(AuthContext);

  return (
    <div style={{padding:20, fontFamily:'Arial'}}>
      <h1>S3 Hackathon Upload</h1>
      <CountdownTimer />
      <Instructions />
      {!user ? (
        <>
          <h2>Login</h2>
          <Login />
          <h2>Register</h2>
          <Register />
        </>
      ) : (
        <>
          <h2>Welcome {user.email} ({user.role})</h2>
          <UploadPanel />
          <FileList />
        </>
      )}
    </div>
  );
}
