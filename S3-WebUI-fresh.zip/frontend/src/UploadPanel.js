import React, { useState, useContext } from 'react';
import api from './api';
import { AuthContext } from './AuthContext';

export default function UploadPanel(){
  const { token, user } = useContext(AuthContext);
  const [files, setFiles] = useState([]);

  function handleFiles(e){
    const list = Array.from(e.target.files || []);
    setFiles(list);
  }

  async function uploadAll(){
    if(!token){ alert('Please login'); return; }
    for(const f of files){
      const filename = f.webkitRelativePath || f.name;
      try{
        const pres = await api.post('/api/generate_presigned_url', { filename }, { headers:{ Authorization: 'Bearer '+token }});
        await fetch(pres.data.url, { method: 'PUT', headers: { 'Content-Type': f.type || 'application/octet-stream' }, body: f });
        console.log('uploaded', filename);
      }catch(e){
        console.error('upload failed', e);
        alert('Upload failed: ' + (e?.response?.data?.detail || e.message));
      }
    }
    alert('Uploads finished (check file list)');
  }

  return (
    <div style={{margin:'12px 0', padding:10, border:'1px solid #ddd'}}>
      <h3>Upload</h3>
      <input type="file" webkitdirectory="true" directory="true" multiple onChange={handleFiles} /><br/>
      <button onClick={uploadAll} style={{marginTop:8}}>Upload selected</button>
      <div>{files.length} files selected</div>
    </div>
  );
}
