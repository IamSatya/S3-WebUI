import React, { useState, useContext } from 'react';
import api from './api';
import { AuthContext } from './AuthContext';

export default function Login(){
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const { saveToken } = useContext(AuthContext);

  async function submit(e){
    e.preventDefault();
    try{
      const res = await api.post('/api/login', { email, password });
      saveToken(res.data.access_token);
      alert('Logged in');
    }catch(err){
      alert('Login failed: ' + (err?.response?.data?.detail || err.message));
    }
  }

  return (
    <form onSubmit={submit}>
      <input placeholder="email" value={email} onChange={e=>setEmail(e.target.value)} /><br/>
      <input placeholder="password" type="password" value={password} onChange={e=>setPassword(e.target.value)} /><br/>
      <button type="submit">Login</button>
    </form>
  );
}
