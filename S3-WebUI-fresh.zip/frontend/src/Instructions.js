import React from 'react';
export default function Instructions(){
  return (
    <div style={{margin:'12px 0', padding:10, border:'1px solid #eee', background:'#fafafa'}}>
      <h3>How to use</h3>
      <ol>
        <li>Register and login with your email.</li>
        <li>Use the Upload panel to select files or a folder to upload.</li>
        <li>Only your uploaded files/folders are visible to you. Admin can see all.</li>
        <li>The upload button will be disabled after the deadline.</li>
      </ol>
    </div>
  );
}
