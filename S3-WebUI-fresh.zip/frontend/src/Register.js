import React, { useState } from 'react';
import api from './api';

export default function Register(){
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  async function submit(e){
    e.preventDefault();
    try{
      await api.post('/api/register', { email, password });
      alert('Registered. Please login.');
    }catch(err){
      alert('Register failed: ' + (err?.response?.data?.detail || err.message));
    }
  }

  return (
    <form onSubmit={submit}>
      <input placeholder="email" value={email} onChange={e=>setEmail(e.target.value)} /><br/>
      <input placeholder="password" type="password" value={password} onChange={e=>setPassword(e.target.value)} /><br/>
      <button type="submit">Register</button>
    </form>
  );
}
