import React, { useEffect, useState, useContext } from 'react';
import api from './api';
import { AuthContext } from './AuthContext';

export default function CountdownTimer(){
  const [cutoff, setCutoff] = useState(null);
  const [remaining, setRemaining] = useState('');
  const { token } = useContext(AuthContext);

  useEffect(()=>{
    async function fetchCutoff(){
      try{
        const res = await api.get('/api/cutoff', { headers: token ? { Authorization: 'Bearer '+token } : {} });
        setCutoff(res.data.cutoff || null);
      }catch(e){
        console.warn('cutoff fetch failed', e);
      }
    }
    fetchCutoff();
  }, [token]);

  useEffect(()=>{
    if(!cutoff) return;
    const tgt = new Date(cutoff);
    const iv = setInterval(()=>{
      const diff = tgt - new Date();
      if(diff<=0){ setRemaining('Deadline passed'); clearInterval(iv); }
      else {
        const d = Math.floor(diff/86400000);
        const h = Math.floor((diff%86400000)/3600000);
        const m = Math.floor((diff%3600000)/60000);
        const s = Math.floor((diff%60000)/1000);
        setRemaining(`${d}d ${h}h ${m}m ${s}s`);
      }
    }, 1000);
    return ()=>clearInterval(iv);
  }, [cutoff]);

  if(!cutoff) return null;
  return <div style={{margin:'8px 0', padding:8, border:'1px solid #ddd'}}><strong>Upload deadline:</strong> {cutoff} — <em>{remaining}</em></div>;
}
