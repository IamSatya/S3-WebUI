import React, { useEffect, useState, useContext } from 'react';
import api from './api';
import { AuthContext } from './AuthContext';

export default function FileList(){
  const { token } = useContext(AuthContext);
  const [items, setItems] = useState([]);

  async function fetchList(){
    if(!token) return;
    try{
      const res = await api.get('/api/list_files?prefix=', { headers: { Authorization: 'Bearer '+token }});
      setItems(res.data.items || []);
    }catch(e){
      console.error('list failed', e);
    }
  }

  useEffect(()=>{ fetchList(); }, [token]);

  async function download(key){
    try{
      const res = await api.get('/api/get_presigned_download?key=' + encodeURIComponent(key), { headers: { Authorization: 'Bearer '+token }});
      window.open(res.data.url, '_blank');
    }catch(e){ alert('download failed'); }
  }

  async function del(key){
    if(!confirm('Delete ' + key + '?')) return;
    try{
      await api.delete('/api/delete_object?key=' + encodeURIComponent(key), { headers: { Authorization: 'Bearer '+token }});
      fetchList();
    }catch(e){ alert('delete failed'); }
  }

  return (
    <div style={{margin:'12px 0', padding:10, border:'1px solid #eee'}}>
      <h3>Your files</h3>
      <button onClick={fetchList}>Refresh</button>
      <ul>
        {items.map(it=>(
          <li key={it.key}>
            {it.key} &nbsp; ({it.size} bytes)
            <button onClick={()=>download(it.key)}>Download</button>
            <button onClick={()=>del(it.key)}>Delete</button>
          </li>
        ))}
      </ul>
    </div>
  );
}
