import React, { createContext, useState, useEffect } from 'react';
import api from './api';

export const AuthContext = createContext();

export default function AuthProvider({ children }){
  const [token, setToken] = useState(localStorage.getItem('access_token') || null);
  const [user, setUser] = useState(null);

  useEffect(()=>{
    async function fetchMe(){
      if(!token){ setUser(null); return; }
      try{
        const res = await api.get('/api/me', { headers: { Authorization: 'Bearer ' + token } });
        setUser(res.data);
      }catch(e){
        console.error('me failed', e);
        setUser(null);
        setToken(null);
        localStorage.removeItem('access_token');
      }
    }
    fetchMe();
  }, [token]);

  function saveToken(t){
    if(t) localStorage.setItem('access_token', t);
    else localStorage.removeItem('access_token');
    setToken(t);
  }

  return <AuthContext.Provider value={{ token, saveToken, user }}>{children}</AuthContext.Provider>;
}
