S3 Hackathon App - Minimal fullstack scaffold

Contents:
- backend/: FastAPI backend (app.py, requirements.txt, Dockerfile)
- frontend/: React app scaffold (src/, package.json, Dockerfile)

Quick steps (example):
1. Create a .env file with AWS credentials and settings, e.g.:
   S3_BUCKET=your-bucket
   AWS_REGION=ap-south-1
   AWS_ACCESS_KEY_ID=...
   AWS_SECRET_ACCESS_KEY=...
   JWT_SECRET=change-me
   HACKATHON_CUTOFF_ISO=2025-10-25T18:00:00+05:30
   ADMIN_USER_EMAIL=admin@example.com
   ADMIN_USER_PASSWORD=AdminPass123

2. Build and run using docker-compose (ensure you have docker and docker-compose):
   docker-compose up --build -d

3. Frontend will be available on port 80, backend on 8000.
