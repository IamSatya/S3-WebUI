import os
import re
from datetime import datetime, timedelta, timezone
from typing import Optional
from fastapi import FastAPI, HTTPException, Depends, Header
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, EmailStr
import boto3
from jose import jwt, JWTError
from passlib.context import CryptContext
import sqlite3

# ---------- Config ----------
S3_BUCKET = os.getenv("S3_BUCKET", "your-bucket")
AWS_REGION = os.getenv("AWS_REGION", "us-east-1")
JWT_SECRET = os.getenv("JWT_SECRET", "change-me")
ACCESS_TOKEN_EXPIRE_MINUTES = int(os.getenv("ACCESS_TOKEN_EXPIRE_MINUTES", "43200"))
HACKATHON_CUTOFF_ISO = os.getenv("HACKATHON_CUTOFF_ISO", "")
ADMIN_USER_EMAIL = os.getenv("ADMIN_USER_EMAIL", "")
ADMIN_USER_PASSWORD = os.getenv("ADMIN_USER_PASSWORD", "")

if not S3_BUCKET:
    print("WARNING: S3_BUCKET not set - backend will still run but S3 calls will fail.")

s3 = boto3.client("s3", region_name=AWS_REGION)

pwd_ctx = CryptContext(schemes=["bcrypt"], deprecated="auto")
ALGORITHM = "HS256"

def hash_password(pw: str) -> str:
    return pwd_ctx.hash(pw)

def verify_password(plain, hashed) -> bool:
    return pwd_ctx.verify(plain, hashed)

def create_access_token(data: dict, expires_delta: Optional[timedelta] = None):
    to_encode = data.copy()
    expire = datetime.now(timezone.utc) + (expires_delta or timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES))
    to_encode.update({"exp": int(expire.timestamp())})
    return jwt.encode(to_encode, JWT_SECRET, algorithm=ALGORITHM)

def decode_token(token: str):
    try:
        payload = jwt.decode(token, JWT_SECRET, algorithms=[ALGORITHM])
        return payload
    except JWTError:
        return None

DB_PATH = os.path.join(os.path.dirname(__file__), "users.db")

def init_db():
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("""CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        email TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        role TEXT NOT NULL DEFAULT 'user'
    )""")
    conn.commit()
    conn.close()

def create_user(email: str, password: str, role: str = "user"):
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    try:
        cur.execute("INSERT INTO users (email, password_hash, role) VALUES (?, ?, ?)",
                    (email, hash_password(password), role))
        conn.commit()
    except sqlite3.IntegrityError:
        conn.close()
        raise ValueError("Email already exists")
    conn.close()

def get_user_by_email(email: str):
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("SELECT id, email, password_hash, role FROM users WHERE email=?", (email,))
    row = cur.fetchone()
    conn.close()
    if row:
        return {"id": row[0], "email": row[1], "password_hash": row[2], "role": row[3]}
    return None

def safe_prefix_from_email(email: str) -> str:
    safe = re.sub(r'[^A-Za-z0-9_\-]', '_', email)
    return f"users/{safe}/"

def cutoff_passed() -> bool:
    if not HACKATHON_CUTOFF_ISO:
        return False
    try:
        cutoff = datetime.fromisoformat(HACKATHON_CUTOFF_ISO)
    except Exception:
        return False
    now = datetime.now(cutoff.tzinfo or timezone.utc)
    return now >= cutoff

app = FastAPI(title="S3 Hackathon API")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

class RegisterIn(BaseModel):
    email: EmailStr
    password: str

class TokenOut(BaseModel):
    access_token: str
    token_type: str = "bearer"
    role: str

class PresignIn(BaseModel):
    filename: str
    filetype: Optional[str] = None

def get_current_user(authorization: Optional[str] = Header(None)):
    if not authorization:
        raise HTTPException(status_code=401, detail="Missing Authorization header")
    if not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Invalid Authorization header")
    token = authorization.split(" ", 1)[1]
    payload = decode_token(token)
    if not payload:
        raise HTTPException(status_code=401, detail="Invalid token")
    email = payload.get("sub")
    if not email:
        raise HTTPException(status_code=401, detail="Invalid token payload")
    user = get_user_by_email(email)
    if not user:
        raise HTTPException(status_code=401, detail="User not found")
    return user

@app.on_event("startup")
def startup():
    init_db()
    if ADMIN_USER_EMAIL and ADMIN_USER_PASSWORD:
        try:
            create_user(ADMIN_USER_EMAIL, ADMIN_USER_PASSWORD, role="admin")
            print("Admin user created")
        except Exception:
            pass

@app.post("/api/register")
def register(payload: RegisterIn):
    try:
        create_user(payload.email, payload.password)
        return {"message": "Registered"}
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.post("/api/login", response_model=TokenOut)
def login(payload: RegisterIn):
    user = get_user_by_email(payload.email)
    if not user or not verify_password(payload.password, user["password_hash"]):
        raise HTTPException(status_code=401, detail="Invalid credentials")
    token = create_access_token({"sub": user["email"], "role": user["role"]})
    return {"access_token": token, "role": user["role"]}

@app.get("/api/me")
def me(user=Depends(get_current_user)):
    return {"email": user["email"], "role": user["role"]}

@app.post("/api/generate_presigned_url")
def generate_presigned_url(body: PresignIn, user=Depends(get_current_user)):
    if cutoff_passed() and user["role"] != "admin":
        raise HTTPException(status_code=403, detail="Upload cutoff passed")
    prefix = safe_prefix_from_email(user["email"]) if user["role"] != "admin" else ""
    if not body.filename.startswith(prefix):
        key = prefix + body.filename.lstrip("/")
    else:
        key = body.filename
    content_type = body.filetype or "application/octet-stream"
    try:
        url = s3.generate_presigned_url(
            "put_object",
            Params={"Bucket": S3_BUCKET, "Key": key, "ContentType": content_type},
            ExpiresIn=3600,
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    return {"url": url, "key": key}

@app.get("/api/list_files")
def list_files(prefix: Optional[str] = "", user=Depends(get_current_user)):
    if user["role"] != "admin":
        effective_prefix = safe_prefix_from_email(user["email"]) + (prefix or "")
    else:
        effective_prefix = prefix or ""
    try:
        resp = s3.list_objects_v2(Bucket=S3_BUCKET, Prefix=effective_prefix)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    items = []
    for obj in resp.get("Contents", []):
        items.append({
            "key": obj["Key"],
            "size": obj["Size"],
            "last_modified": obj["LastModified"].isoformat()
        })
    return {"items": items, "prefix": effective_prefix}

@app.get("/api/get_presigned_download")
def get_presigned_download(key: str, user=Depends(get_current_user)):
    if user["role"] != "admin" and not key.startswith(safe_prefix_from_email(user["email"])):
        raise HTTPException(status_code=403, detail="Not allowed")
    try:
        url = s3.generate_presigned_url("get_object", Params={"Bucket": S3_BUCKET, "Key": key}, ExpiresIn=3600)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    return {"url": url}

@app.delete("/api/delete_object")
def delete_object(key: str, user=Depends(get_current_user)):
    if user["role"] != "admin" and not key.startswith(safe_prefix_from_email(user["email"])):
        raise HTTPException(status_code=403, detail="Not allowed to delete this object")
    try:
        s3.delete_object(Bucket=S3_BUCKET, Key=key)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    return {"message": f"{key} deleted successfully"}

@app.post("/api/create_folder")
def create_folder(prefix: str, user=Depends(get_current_user)):
    if not prefix.endswith("/"):
        prefix = prefix + "/"
    if user["role"] != "admin" and not prefix.startswith(safe_prefix_from_email(user["email"])):
        raise HTTPException(status_code=403, detail="Not allowed to create folder here")
    try:
        s3.put_object(Bucket=S3_BUCKET, Key=prefix)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    return {"message": f"Folder '{prefix}' created successfully"}

@app.get("/api/cutoff")
def cutoff(user=Depends(get_current_user)):
    return {"cutoff": HACKATHON_CUTOFF_ISO}
