\
import React, {useState, useEffect} from "react";

const API = "/api"; // proxied in docker-compose via ports

function App(){
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [token, setToken] = useState(localStorage.getItem("token")||"");
  const [files, setFiles] = useState([]);
  const [fileInput, setFileInput] = useState(null);
  const [message, setMessage] = useState("");

  useEffect(()=>{ if(token) fetchList(); }, [token]);

  async function register(){
    const form = new FormData();
    form.append("email", email);
    form.append("password", password);
    const r = await fetch("http://localhost:8000/register", {method:"POST", body: form});
    const j = await r.json().catch(()=>({status:r.status}));
    setMessage(JSON.stringify(j));
  }
  async function login(){
    const form = new FormData();
    form.append("email", email);
    form.append("password", password);
    const r = await fetch("http://localhost:8000/login", {method:"POST", body: form});
    if(!r.ok){ setMessage("Login failed"); return; }
    const j = await r.json();
    setToken(j.access_token); localStorage.setItem("token", j.access_token);
    setMessage("Logged in");
  }
  async function upload(){
    if(!fileInput){ setMessage("Select file"); return; }
    const form = new FormData();
    form.append("token", token);
    form.append("file", fileInput);
    const r = await fetch("http://localhost:8000/api/upload", {method:"POST", body: form});
    const j = await r.json();
    setMessage(JSON.stringify(j));
    fetchList();
  }
  async function fetchList(){
    const form = new FormData();
    form.append("token", token);
    const r = await fetch("http://localhost:8000/api/list_files", {method:"POST", body: form});
    const j = await r.json();
    setFiles(j);
  }
  async function download(id, name){
    const form = new FormData(); form.append("token", token);
    const res = await fetch(`http://localhost:8000/api/download/${id}`, {method:"POST", body: form});
    if(res.ok){
      const blob = await res.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a"); a.href = url; a.download = name; a.click();
    } else {
      setMessage("Download failed");
    }
  }
  async function del(id){ const form = new FormData(); form.append("token", token); const r=await fetch(`http://localhost:8000/api/delete/${id}`,{method:"POST",body:form}); setMessage(await r.json().then(x=>JSON.stringify(x))); fetchList(); }

  return (<div style={{padding:20,fontFamily:'Arial'}}>
    <h2>S3 Hackathon App (minimal)</h2>
    <div style={{border:'1px solid #ccc',padding:10,marginBottom:10}}>
      <h3>Auth</h3>
      <input placeholder="email" value={email} onChange={e=>setEmail(e.target.value)}/> <br/>
      <input placeholder="password" type="password" value={password} onChange={e=>setPassword(e.target.value)}/> <br/>
      <button onClick={register}>Register</button>
      <button onClick={login}>Login</button>
      <button onClick={()=>{localStorage.removeItem('token'); setToken(''); setMessage('Logged out');}}>Logout</button>
    </div>

    <div style={{border:'1px solid #ccc',padding:10,marginBottom:10}}>
      <h3>Upload (user-scoped)</h3>
      <input type="file" onChange={e=>setFileInput(e.target.files[0])}/>
      <button onClick={upload}>Upload</button>
    </div>

    <div style={{border:'1px solid #ccc',padding:10,marginBottom:10}}>
      <h3>Your Files</h3>
      <button onClick={fetchList}>Refresh</button>
      <ul>{files.map(f=>(<li key={f.id}>{f.filename} &nbsp;
        <button onClick={()=>download(f.id,f.filename)}>Download</button>
        <button onClick={()=>del(f.id)}>Delete</button>
      </li>))}</ul>
    </div>

    <div style={{border:'1px solid #eee',padding:10}}><strong>Message:</strong> {message}</div>
  </div>);
}

export default App;
