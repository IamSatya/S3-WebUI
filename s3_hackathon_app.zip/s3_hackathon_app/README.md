# S3 Hackathon App

Run `docker-compose up --build`.
