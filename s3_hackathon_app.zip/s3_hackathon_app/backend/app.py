
import os, shutil, boto3, datetime
from typing import Optional, List
from fastapi import FastAPI, HTTPException, Depends, UploadFile, File, Form
from fastapi.responses import FileResponse
from passlib.hash import bcrypt
from jose import jwt, JWTError
from sqlalchemy import create_engine, Column, Integer, String, DateTime, Text
from sqlalchemy.orm import sessionmaker, declarative_base

DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./data/hackathon.db")
UPLOAD_DIR = os.getenv("UPLOAD_DIR", "/app/data/uploads")
HACKATHON_CUTOFF = os.getenv("HACKATHON_CUTOFF", "2025-11-05T18:00:00+05:30")
SECRET_KEY = os.getenv("SECRET_KEY", "please_change_this_in_prod")
ALGORITHM = "HS256"

os.makedirs(UPLOAD_DIR, exist_ok=True)

# DB setup
engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False} if DATABASE_URL.startswith("sqlite") else {})
SessionLocal = sessionmaker(bind=engine)
Base = declarative_base()

class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True, index=True)
    email = Column(String, unique=True, index=True)
    hashed = Column(String)

class FileMeta(Base):
    __tablename__ = "files"
    id = Column(Integer, primary_key=True, index=True)
    owner = Column(String, index=True)
    key = Column(String, index=True)
    filename = Column(String)
    created = Column(DateTime, default=datetime.datetime.utcnow)

Base.metadata.create_all(bind=engine)

app = FastAPI(title="S3 Hackathon API")

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

def create_token(email:str):
    to_encode = {"sub": email, "exp": datetime.datetime.utcnow() + datetime.timedelta(hours=10)}
    return jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)

def get_current_user(token: str = Form(...), db=Depends(get_db)):
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        email = payload.get("sub")
        if not email:
            raise HTTPException(status_code=401, detail="Invalid token")
    except JWTError:
        raise HTTPException(status_code=401, detail="Invalid token")
    user = db.query(User).filter(User.email==email).first()
    if not user:
        raise HTTPException(status_code=401, detail="Invalid token")
    return user.email

@app.post("/register")
def register(email: str = Form(...), password: str = Form(...), db=Depends(get_db)):
    if db.query(User).filter(User.email==email).first():
        raise HTTPException(status_code=400, detail="User exists or DB error")
    user = User(email=email, hashed=bcrypt.hash(password))
    db.add(user); db.commit()
    return {"detail":"ok"}

@app.post("/login")
def login(email: str = Form(...), password: str = Form(...), db=Depends(get_db)):
    user = db.query(User).filter(User.email==email).first()
    if not user or not bcrypt.verify(password, user.hashed):
        raise HTTPException(status_code=401, detail="Invalid credentials")
    token = create_token(email)
    return {"access_token": token}

def uploads_allowed():
    cutoff = datetime.datetime.fromisoformat(HACKATHON_CUTOFF)
    return datetime.datetime.now(datetime.timezone.utc).astimezone() < cutoff

@app.post("/api/upload")
def upload_file(token: str = Form(...), file: UploadFile = File(...), prefix: str = Form(""), db=Depends(get_db)):
    owner = get_current_user(token, db)
    if not uploads_allowed():
        raise HTTPException(status_code=403, detail="Upload window closed")
    safe_prefix = f"users/{owner}/{prefix}".strip("/")
    os.makedirs(os.path.join(UPLOAD_DIR, safe_prefix), exist_ok=True)
    path = os.path.join(UPLOAD_DIR, safe_prefix, file.filename)
    with open(path, "wb") as f:
        shutil.copyfileobj(file.file, f)
    meta = FileMeta(owner=owner, key=os.path.relpath(path, UPLOAD_DIR), filename=file.filename)
    db.add(meta); db.commit()
    return {"detail":"uploaded","key":meta.key}

@app.get("/api/list_files")
def list_files(prefix: Optional[str] = "", token: str = Form(...), db=Depends(get_db)):
    owner = get_current_user(token, db)
    files = db.query(FileMeta).filter(FileMeta.owner==owner).all()
    out = []
    for f in files:
        if prefix=="" or f.key.startswith(prefix):
            out.append({"id":f.id,"key":f.key,"filename":f.filename,"created":f.created.isoformat()})
    return out

@app.get("/api/download/{file_id}")
def download(file_id: int, token: str = Form(...), db=Depends(get_db)):
    owner = get_current_user(token, db)
    f = db.query(FileMeta).filter(FileMeta.id==file_id, FileMeta.owner==owner).first()
    if not f:
        raise HTTPException(status_code=404, detail="Not found")
    path = os.path.join(UPLOAD_DIR, f.key)
    if not os.path.exists(path):
        raise HTTPException(status_code=404, detail="Missing file on disk")
    return FileResponse(path, filename=f.filename)

@app.post("/api/delete/{file_id}")
def delete(file_id: int, token: str = Form(...), db=Depends(get_db)):
    owner = get_current_user(token, db)
    f = db.query(FileMeta).filter(FileMeta.id==file_id, FileMeta.owner==owner).first()
    if not f:
        raise HTTPException(status_code=404, detail="Not found")
    path = os.path.join(UPLOAD_DIR, f.key)
    try:
        if os.path.exists(path):
            os.remove(path)
    except Exception:
        pass
    db.delete(f); db.commit()
    return {"detail":"deleted"}

@app.get("/api/me")
def me(token: str = Form(...), db=Depends(get_db)):
    owner = get_current_user(token, db)
    return {"email": owner}
