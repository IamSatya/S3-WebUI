import os
from fastapi import FastAPI, HTTPException, Depends, UploadFile, File, Form
from fastapi.responses import FileResponse
from fastapi.middleware.cors import CORSMiddleware
from passlib.context import CryptContext
from jose import jwt, JWTError
import sqlite3
from datetime import datetime, timezone
import shutil

UPLOAD_DIR = os.environ.get("UPLOAD_DIR", "/app/data/uploads")
os.makedirs(UPLOAD_DIR, exist_ok=True)

DB_PATH = os.path.join(os.path.dirname(__file__), "data", "hackathon.db")

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
SECRET_KEY = os.environ.get("SECRET_KEY", "please_change_this_in_prod")
ALGORITHM = "HS256"
HACKATHON_CUTOFF = os.environ.get("HACKATHON_CUTOFF", "2025-11-05T18:00:00+05:30")

app = FastAPI()
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

def get_conn():
    conn = sqlite3.connect(DB_PATH, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_conn()
    cur = conn.cursor()
    cur.execute('''CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        email TEXT UNIQUE,
        password TEXT
    )''')
    cur.execute('''CREATE TABLE IF NOT EXISTS files (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_email TEXT,
        path TEXT,
        uploaded_at TEXT
    )''')
    conn.commit()
    conn.close()

init_db()

def create_access_token(data: dict):
    to_encode = data.copy()
    to_encode["exp"] = int(datetime.now(tz=timezone.utc).timestamp()) + 60*60*24*7
    return jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)

def verify_token(token: str):
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        return payload.get("sub")
    except JWTError:
        return None

@app.post("/api/register")
def register(email: str = Form(...), password: str = Form(...)):
    conn = get_conn()
    cur = conn.cursor()
    hashed = pwd_context.hash(password)
    try:
        cur.execute("INSERT INTO users (email, password) VALUES (?, ?)", (email, hashed))
        conn.commit()
    except sqlite3.IntegrityError:
        conn.close()
        raise HTTPException(status_code=400, detail="User exists or DB error")
    conn.close()
    return {"detail": "ok"}

@app.post("/api/login")
def login(email: str = Form(...), password: str = Form(...)):
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("SELECT * FROM users WHERE email=?", (email,))
    row = cur.fetchone()
    conn.close()
    if not row or not pwd_context.verify(password, row["password"]):
        raise HTTPException(status_code=401, detail="Invalid credentials")
    token = create_access_token({"sub": email})
    return {"access_token": token, "token_type": "bearer"}

def get_current_user(token: str = Form(None), authorization: str = None):
    if authorization:
        parts = authorization.split()
        if len(parts) == 2 and parts[0].lower() == "bearer":
            token = parts[1]
    if not token:
        raise HTTPException(status_code=401, detail="Not authenticated")
    email = verify_token(token)
    if not email:
        raise HTTPException(status_code=401, detail="Invalid token")
    return email

def cutoff_passed():
    cutoff = datetime.fromisoformat(HACKATHON_CUTOFF)
    now = datetime.now(timezone.utc).astimezone(cutoff.tzinfo)
    return now > cutoff

@app.post("/api/upload")
def upload_file(file: UploadFile = File(...), token: str = Form(None), authorization: str = None):
    user = get_current_user(token, authorization)
    if cutoff_passed():
        raise HTTPException(status_code=403, detail="Upload cutoff passed")
    user_dir = os.path.join(UPLOAD_DIR, user)
    os.makedirs(user_dir, exist_ok=True)
    dest_path = os.path.join(user_dir, file.filename)
    with open(dest_path, "wb") as f:
        shutil.copyfileobj(file.file, f)
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("INSERT INTO files (user_email, path, uploaded_at) VALUES (?, ?, ?)", (user, dest_path, datetime.utcnow().isoformat()))
    conn.commit()
    conn.close()
    return {"detail": "uploaded", "path": dest_path}

@app.get("/api/list_files")
def list_files(token: str = None, authorization: str = None):
    user = get_current_user(token, authorization)
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("SELECT id, path, uploaded_at FROM files WHERE user_email=?", (user,))
    rows = [dict(r) for r in cur.fetchall()]
    conn.close()
    for r in rows:
        r["filename"] = os.path.basename(r["path"])
    return {"files": rows}

@app.get("/api/download/{file_id}")
def download_file(file_id: int, token: str = None, authorization: str = None):
    user = get_current_user(token, authorization)
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("SELECT path, user_email FROM files WHERE id=?", (file_id,))
    row = cur.fetchone()
    conn.close()
    if not row:
        raise HTTPException(status_code=404, detail="Not found")
    if row["user_email"] != user:
        raise HTTPException(status_code=403, detail="Forbidden")
    return FileResponse(row["path"], filename=os.path.basename(row["path"]))

@app.delete("/api/delete/{file_id}")
def delete_file(file_id: int, token: str = None, authorization: str = None):
    user = get_current_user(token, authorization)
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("SELECT path, user_email FROM files WHERE id=?", (file_id,))
    row = cur.fetchone()
    if not row:
        conn.close()
        raise HTTPException(status_code=404, detail="Not found")
    if row["user_email"] != user:
        conn.close()
        raise HTTPException(status_code=403, detail="Forbidden")
    try:
        os.remove(row["path"])
    except Exception:
        pass
    cur.execute("DELETE FROM files WHERE id=?", (file_id,))
    conn.commit()
    conn.close()
    return {"detail": "deleted"}

@app.get("/api/me")
def me(token: str = None, authorization: str = None):
    user = get_current_user(token, authorization)
    return {"email": user}
