
S3 Hackathon - fixed frontend files added.

How to run:
1. Copy this repository to your server.
2. Create a .env file in the project root with:
   AWS_ACCESS_KEY_ID=...
   AWS_SECRET_ACCESS_KEY=...
   S3_BUCKET=your-bucket
   AWS_REGION=your-region
   JWT_SECRET=change-me
   HACKATHON_CUTOFF_ISO=2025-10-25T18:00:00+05:30

3. Build & run:
   docker-compose up --build -d

Frontend will be on port 80. Backend on 8000.

Notes:
- This is a minimal scaffold. For production harden CORS, secrets, and use proper DB migrations.
