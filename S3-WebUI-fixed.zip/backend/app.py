import os
from datetime import datetime, timedelta
from typing import Optional, List
from fastapi import FastAPI, HTTPException, Depends
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import boto3
import sqlite3
import jwt
from passlib.context import CryptContext

JWT_SECRET = os.getenv("JWT_SECRET", "change-me")
AWS_REGION = os.getenv("AWS_REGION", "us-east-1")
S3_BUCKET = os.getenv("S3_BUCKET", "")
HACKATHON_CUTOFF_ISO = os.getenv("HACKATHON_CUTOFF_ISO")  # e.g. 2025-10-25T18:00:00+05:30

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# simple sqlite helper
DB_PATH = "users.db"
def init_db():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("""CREATE TABLE IF NOT EXISTS users (
                 id INTEGER PRIMARY KEY AUTOINCREMENT,
                 email TEXT UNIQUE,
                 password_hash TEXT,
                 is_admin INTEGER DEFAULT 0
                 )""")
    conn.commit()
    conn.close()

init_db()

class UserCreate(BaseModel):
    email: str
    password: str

class TokenResp(BaseModel):
    access_token: str

def get_user_by_email(email: str):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("SELECT id,email,password_hash,is_admin FROM users WHERE email=?", (email,))
    row = c.fetchone()
    conn.close()
    if not row:
        return None
    return {"id": row[0], "email": row[1], "password_hash": row[2], "is_admin": bool(row[3])}

def create_user(email: str, password: str, is_admin: bool=False):
    ph = pwd_context.hash(password)
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    try:
        c.execute("INSERT INTO users (email, password_hash, is_admin) VALUES (?,?,?)", (email, ph, int(is_admin)))
        conn.commit()
    except Exception as e:
        conn.close()
        raise
    conn.close()

def authenticate_user(email: str, password: str):
    user = get_user_by_email(email)
    if not user:
        return None
    if not pwd_context.verify(password, user["password_hash"]):
        return None
    return user

def create_access_token(data: dict, expires_delta: Optional[timedelta]=None):
    to_encode = data.copy()
    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(hours=8)
    to_encode.update({"exp": expire})
    return jwt.encode(to_encode, JWT_SECRET, algorithm="HS256")

def get_current_user(token: str = Depends(lambda: None)):
    # FastAPI dependency injection won't call lambda this way in production,
    # but for simplicity we'll read Authorization header manually in endpoints.
    return None

# endpoints
@app.post("/api/register", response_model=dict)
def register(u: UserCreate):
    try:
        create_user(u.email, u.password)
    except Exception as e:
        raise HTTPException(status_code=400, detail="User exists or DB error")
    return {"msg": "created"}

@app.post("/api/login", response_model=TokenResp)
def login(u: UserCreate):
    user = authenticate_user(u.email, u.password)
    if not user:
        raise HTTPException(status_code=401, detail="Invalid credentials")
    token = create_access_token({"sub": user["email"], "is_admin": user["is_admin"]})
    return {"access_token": token}

def check_cutoff():
    if HACKATHON_CUTOFF_ISO:
        try:
            cutoff = datetime.fromisoformat(HACKATHON_CUTOFF_ISO)
            if datetime.utcnow() > cutoff:
                return False
        except Exception:
            pass
    return True

def get_email_from_auth(auth_header: Optional[str]):
    if not auth_header:
        return None
    if auth_header.lower().startswith("bearer "):
        token = auth_header.split(" ",1)[1]
    else:
        token = auth_header
    try:
        payload = jwt.decode(token, JWT_SECRET, algorithms=["HS256"])
        return payload.get("sub")
    except Exception:
        return None

@app.get("/api/list_files")
def list_files(prefix: Optional[str] = "", authorization: Optional[str] = ""):
    email = get_email_from_auth(authorization)
    if not email:
        raise HTTPException(status_code=401, detail="Unauthorized")
    s3 = boto3.client("s3", region_name=AWS_REGION)
    user_prefix = f"users/{email}/"
    # only list objects under user's prefix unless admin
    # check admin
    user = get_user_by_email(email)
    if user and user.get("is_admin"):
        final_prefix = prefix or ""
    else:
        final_prefix = user_prefix + (prefix or "")
    try:
        resp = s3.list_objects_v2(Bucket=S3_BUCKET, Prefix=final_prefix)
        items = [obj["Key"] for obj in resp.get("Contents", [])]
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    return {"files": items}

@app.post("/api/generate_presigned_url")
def generate_presigned(data: dict, authorization: Optional[str] = ""):
    email = get_email_from_auth(authorization)
    if not email:
        raise HTTPException(status_code=401, detail="Unauthorized")
    if not check_cutoff():
        raise HTTPException(status_code=403, detail="Upload cutoff reached")
    s3 = boto3.client("s3", region_name=AWS_REGION)
    key = data.get("key")
    if not key:
        raise HTTPException(status_code=400, detail="key required")
    # ensure key is within user's folder
    user_prefix = f"users/{email}/"
    if not key.startswith(user_prefix):
        # force prefix
        key = user_prefix + key.lstrip("/")
    try:
        url = s3.generate_presigned_url("put_object", Params={"Bucket": S3_BUCKET, "Key": key}, ExpiresIn=3600)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    return {"url": url, "key": key}

@app.post("/api/delete_file")
def delete_file(data: dict, authorization: Optional[str] = ""):
    email = get_email_from_auth(authorization)
    if not email:
        raise HTTPException(status_code=401, detail="Unauthorized")
    key = data.get("key")
    if not key:
        raise HTTPException(status_code=400, detail="key required")
    user = get_user_by_email(email)
    if not user:
        raise HTTPException(status_code=401, detail="Unauthorized")
    if not user.get("is_admin") and not key.startswith(f"users/{email}/"):
        raise HTTPException(status_code=403, detail="Forbidden")
    s3 = boto3.client("s3", region_name=AWS_REGION)
    try:
        s3.delete_object(Bucket=S3_BUCKET, Key=key)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    return {"msg":"deleted"}