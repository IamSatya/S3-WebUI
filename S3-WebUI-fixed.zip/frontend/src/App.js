
import React, { useState, useEffect } from "react";

const API_BASE = process.env.REACT_APP_API_BASE || "http://localhost:8000/api";

function authHeader() {
  const t = localStorage.getItem("token");
  if (!t) return {};
  return { Authorization: `Bearer ${t}` };
}

export default function App() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loggedIn, setLoggedIn] = useState(!!localStorage.getItem("token"));
  const [files, setFiles] = useState([]);
  const [message, setMessage] = useState("");
  const [timer, setTimer] = useState("");

  useEffect(() => {
    const cutoff = process.env.REACT_APP_HACKATHON_CUTOFF_ISO;
    if (cutoff) {
      const interval = setInterval(() => {
        const now = new Date();
        const co = new Date(cutoff);
        const diff = co - now;
        if (diff <= 0) setTimer("Upload cutoff reached");
        else {
          const mins = Math.floor(diff / 60000);
          setTimer(`${mins} minutes left`);
        }
      }, 1000);
      return () => clearInterval(interval);
    }
  }, []);

  async function register() {
    const resp = await fetch(`${API_BASE}/register`, {
      method: "POST",
      headers: {"Content-Type":"application/json"},
      body: JSON.stringify({email, password}),
    });
    if (resp.ok) setMessage("Registered OK. Please login.");
    else setMessage("Register failed");
  }

  async function login() {
    const resp = await fetch(`${API_BASE}/login`, {
      method: "POST",
      headers: {"Content-Type":"application/json"},
      body: JSON.stringify({email, password}),
    });
    if (resp.ok) {
      const data = await resp.json();
      localStorage.setItem("token", data.access_token);
      setLoggedIn(true);
      setMessage("Logged in");
      fetchFiles();
    } else {
      setMessage("Login failed");
    }
  }

  async function fetchFiles() {
    const resp = await fetch(`${API_BASE}/list_files?prefix=`, {
      headers: { ...authHeader() }
    });
    if (resp.ok) {
      const data = await resp.json();
      setFiles(data.files || []);
    } else {
      setMessage("Failed to list files");
    }
  }

  async function generatePresigned(e) {
    const file = e.target.files[0];
    if (!file) return;
    const key = `uploads/${file.name}`;
    const resp = await fetch(`${API_BASE}/generate_presigned_url`, {
      method: "POST",
      headers: { "Content-Type":"application/json", ...authHeader() },
      body: JSON.stringify({ key })
    });
    if (!resp.ok) {
      setMessage("Failed to get presigned URL");
      return;
    }
    const { url, key: finalKey } = await resp.json();
    // upload directly
    await fetch(url, { method: "PUT", body: file });
    setMessage("Uploaded. Refreshing list...");
    setTimeout(fetchFiles, 1000);
  }

  async function deleteFile(k) {
    const resp = await fetch(`${API_BASE}/delete_file`, {
      method: "POST",
      headers: { "Content-Type":"application/json", ...authHeader() },
      body: JSON.stringify({ key: k })
    });
    if (resp.ok) {
      setMessage("Deleted");
      fetchFiles();
    } else setMessage("Delete failed");
  }

  return (
    <div style={{ padding: 20 }}>
      <h1>S3 Hackathon UI (fixed)</h1>
      <p>{timer}</p>
      {!loggedIn ? (
        <div>
          <h3>Register / Login</h3>
          <input placeholder="email" value={email} onChange={e=>setEmail(e.target.value)} /><br/>
          <input placeholder="password" type="password" value={password} onChange={e=>setPassword(e.target.value)} /><br/>
          <button onClick={register}>Register</button>
          <button onClick={login}>Login</button>
        </div>
      ) : (
        <div>
          <button onClick={() => { localStorage.removeItem("token"); setLoggedIn(false); setFiles([]); }}>Logout</button>
          <h3>Upload a file (direct upload to S3 via presigned URL)</h3>
          <input type="file" onChange={generatePresigned} />
          <h3>Your files</h3>
          <button onClick={fetchFiles}>Refresh</button>
          <ul>
            {files.map(f => (
              <li key={f}>
                {f} {" "}
                <button onClick={() => deleteFile(f)}>Delete</button>
              </li>
            ))}
          </ul>
        </div>
      )}
      <p>{message}</p>
      <hr />
      <h4>Instructions</h4>
      <ol>
        <li>Register with email/password, then login.</li>
        <li>Use the upload control to select a file — file will be uploaded into your user folder automatically.</li>
        <li>Only files you upload (under users/your-email/) are visible to you. Admin users (if created) can see all files.</li>
        <li>The site enforces a cutoff time (set via REACT_APP_HACKATHON_CUTOFF_ISO) after which uploads are blocked.</li>
      </ol>
    </div>
  );
}
